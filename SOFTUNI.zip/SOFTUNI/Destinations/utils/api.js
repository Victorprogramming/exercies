import { isValidEmail } from './utils.js';
import { routes, notificationTypes, firebaseConfig } from './constants.js';
import { goToRoute } from './router.js';
import events from '../utils/events.js';

class API {
  constructor() {
    if (!!API.instance) {
      return API.instance;
    }

    API.instance = this;

    firebase.initializeApp(firebaseConfig);
    this.auth = firebase.auth();
    this.firestore = firebase.firestore().collection('destinations');

    this.isLoading = true;
    this.destinations = [];

    return this;
  }

  _onSnapshot;
  dataListener = (user) => {
    if (user) {
      this._onSnapshot = this.firestore.onSnapshot(({ docs }) => {
        this.isLoading = false;
        this.destinations = docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        events.trigger('dataChange', true);
      });
    } else {
      if (this._onSnapshot) {
        this._onSnapshot();
      }
      this.isLoading = true;
      this.destinations = [];
    }
  };

  get user() {
    return this.auth.currentUser;
  }

  notify = (message, type, timeout) => events.trigger('notification', { message, type, timeout });

  createUserWithEmailAndPassword = (email, password, confirmPassword) => {
    if (!isValidEmail(email)) {
      return this.notify('Email address is not in a valid format!');
    }

    if (password.length < 6) {
      return this.notify('Password must be at least 6 characters long!');
    }

    if (confirmPassword !== password) {
      return this.notify("Passwords don't match!");
    }

    events.trigger('loading', true);
    this.auth
      .createUserWithEmailAndPassword(email, password)
      .then(() => {
        this.notify('Successful registration!', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };

  signInWithEmailAndPassword = (email, password) => {
    if (!isValidEmail(email)) {
      return this.notify('Email address is not in a valid format!');
    }

    if (!password.length) {
      return this.notify('Please enter a password!');
    }

    events.trigger('loading', true);
    this.auth
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        this.notify('Logged in successfully', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };

  signOut = () => {
    events.trigger('loading', true);
    this.auth
      .signOut()
      .then(() => {
        this.notify('Successful logout', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };

  create = (name, city, duration, departure, imageUrl) => {
    if ([name, city, duration, departure, imageUrl].filter((value) => !value).length) {
      return this.notify('Invalid inputs!');
    }

    events.trigger('loading', true);
    this.firestore
      .add({
        name,
        city,
        duration,
        departure,
        imageUrl,
        creator: this.user.uid,
      })
      .then(() => {
        this.notify('Created successfully', notificationTypes.SUCCESS);
        goToRoute([routes.HOME]);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };

  edit = (name, city, duration, departure, imageUrl, dest) => {
    if ([name, city, duration, departure, imageUrl].filter((value) => !value).length) {
      return this.notify('Invalid inputs!');
    }

    const entries = Object.entries({ name, city, duration, departure, imageUrl }).filter(
      ([field, value]) => value !== dest[field]
    );

    if (!entries.length) {
      this.notify('Successfully edited destination.', notificationTypes.SUCCESS);
      return goToRoute([routes.DETAILS, dest.id]);
    }

    events.trigger('loading', true);
    this.firestore
      .doc(dest.id)
      .update(Object.fromEntries(entries))
      .then(() => {
        this.notify('Successfully edited destination.', notificationTypes.SUCCESS);
        goToRoute([routes.DETAILS, dest.id]);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };

  delete = (id) => {
    events.trigger('loading', true);
    this.firestore
      .doc(id)
      .delete()
      .then(() => {
        this.notify('Destination deleted.', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      })
      .finally(() => {
        events.trigger('loading', false);
      });
  };
}

const api = new API();
export default api;
