export const routes = {
  HOME: '',
  LOGIN: 'login',
  REGISTER: 'register',
  ADD: 'add',
  EDIT: 'edit',
  DETAILS: 'details',
  DESTINATIONS: 'destinations',
};

export const authResRoutes = {
  true: [routes.LOGIN, routes.REGISTER],
  false: [routes.ADD, routes.DETAILS, routes.EDIT, routes.DESTINATIONS],
};

export const firebaseConfig = {
  apiKey: 'AIzaSyDnJd1gwo3K-q7rWuqc82SV77r4jpgy5Ug',
  authDomain: 'vic-prep.firebaseapp.com',
  projectId: 'vic-prep',
  storageBucket: 'vic-prep.appspot.com',
  messagingSenderId: '494516746892',
  appId: '1:494516746892:web:9e9271a1d4ce75b40259a9',
};

export const notificationTypes = {
  SUCCESS: 1,
  ERROR: 2,
};
