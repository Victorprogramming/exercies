import api from '../utils/api.js';
import events from '../utils/events.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  let wrapper, id, dest;

  const render = ({ user, route }) => {
    if (dest && api.destinations.find((dest) => dest.id === id)) {
      return;
    }

    if (wrapper) {
      parent.removeChild(wrapper);
    }

    if (!(id = route[1]) || !(dest = api.destinations.find((dest) => dest.id === id))) {
      wrapper = htmlToParent(
        `<section id="viewEditdestination">
            ${
              api.isLoading
                ? '<h4>Loading...<h4>'
                : `<h4>Destination with id ${id} not found.<br/><br/>Migh have been deleted or might be in create operation.</h4>`
            }
        </desction>`
      );
    } else {
      wrapper = htmlToParent(
        `<section id="viewEditdestination">
            <h2>Edit existing destination</h2>
            <form id="formAdddestination">
                <label for="destination">Destination name:</label>
                <input type="text" id="destination" name="destination" value="${dest.name}">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" value="${dest.city}">
                <label for="duration">Duration:</label>
                <input type="number" id="duration" name="duration" value="${dest.duration}">
                <label for="departureDate">Departure Date:</label>
                <input type="date" id="departureDate" name="departureDate" value="${dest.departure}">
                <label for="imgUrl">Image:</label>
                <input type="text" id="imgUrl" name="imgUrl" value="${dest.imageUrl}">

                <input type="submit" class="create" value="Edit">
            </form>
        </section>`
      );

      wrapper.children[1].addEventListener('submit', (event) => {
        event.preventDefault();
        api.edit(
          ...Array.from(event.target)
            .slice(0, 5)
            .map((el) => el.value.trim()),
          dest
        );
      });
    }
  };

  render({ user: api.user, route });
  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    cleanUp: () => {
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
      parent.removeChild(wrapper);
    },
  };
};
