import api from '../utils/api.js';
import { routes } from '../utils/constants.js';
import events from '../utils/events.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  let wrapper;
  const render = ({ user, route }) => {
    if (wrapper) {
      parent.removeChild(wrapper);
    }

    let id, dest;

    if (!(id = route[1]) || !(dest = api.destinations.find((dest) => dest.id === id))) {
      events.trigger('loading', api.isLoading);
      wrapper = htmlToParent(
        `<section id="viewdestinationDetails">
            ${
              api.isLoading
                ? ''
                : `<h4>Destination with id ${id} was not found.<br/><br/>Migh have been deleted or might be in create operation.</h4>`
            }
        </section>`
      );
    } else {
      events.trigger('loading', false);
      wrapper = htmlToParent(
        `<section id="viewdestinationDetails">
            <div class="destination-area">
                <div class="destination-area-left">
                    <img src="${dest.imageUrl}" alt="">
                </div>
                <div class="destination-area-right">
                    <h3>${dest.name}</h3>
                    <div>to ${dest.city}</div>
                    <div class="data-and-time">
                        ${dest.departure}
                        ${
                          dest.creator === user.uid
                            ? `<a href="#/${routes.EDIT}/${dest.id}" class="edit-destination-detail"></a>`
                            : ''
                        }
                    </div>
                    <div>
                        ${dest.duration} days
                    </div>
                </div>
            </div>
        </section>`
      );
    }
  };

  render({ user: api.user, route });

  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    cleanUp: () => {
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
      parent.removeChild(wrapper);
    },
  };
};
