import { parseHTMLElement } from '../utils/utils.js';

export default ({ parent }) => {
  const wrapper = parent.appendChild(parseHTMLElement(`<footer>@SoftUni Destinations 2020</footer>`));

  return {
    wrapper,
    cleanUp: () => {},
  };
};
