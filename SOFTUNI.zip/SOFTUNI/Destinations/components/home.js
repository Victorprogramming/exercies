import { routes } from '../utils/constants.js';
import api from '../utils/api.js';
import events from '../utils/events.js';
import { parseHTMLElement, parseHTMLElements } from '../utils/utils.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(`<section id="viewCatalog" class="background-img"></section>`);

  let partials = [];

  const render = ({ user, route }) => {
    partials.forEach((element) => wrapper.removeChild(element));
    partials.length = 0;

    if (user) {
      events.trigger('loading', api.isLoading);
      partials = parseHTMLElements(`<div class="added-destinations">
        ${api.destinations
          .map(
            ({ id, name, city, duration, departure, imageUrl, creator }) =>
              `<a href="#/${routes.DETAILS}/${id}" class="added-destination">
                  <img src="${imageUrl}" alt="" class="picture-added-destination">
                  <h3>${name}</h3>
                  <span>to ${city}</span><span>${departure}</span>
              </a>`
          )
          .join('')}
      </div>`);
    } else {
      partials = parseHTMLElements(`<div class="guest">No destinations possible! Please sign in...</div>`);
    }

    wrapper.append(...partials);
  };

  render({ user: api.user, route });

  events.listen('authChange', `${route[0]}-${routerID}`, render);
  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    wrapper,
    cleanUp: () => {
      events.unlisten('authChange', `${route[0]}-${routerID}`);
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
    },
  };
};
