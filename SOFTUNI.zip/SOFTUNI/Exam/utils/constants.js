export const routes = {
  HOME: '',
  LOGIN: 'login',
  REGISTER: 'register',
  ADD: 'add',
  EDIT: 'edit',
  DETAILS: 'details',
  DASHBOARD: 'dashboard',
};

export const authResRoutes = {
  true: [routes.LOGIN, routes.REGISTER],
  false: [routes.ADD, routes.DETAILS, routes.EDIT, routes.DASHBOARD],
};

export const firebaseConfig = {
  apiKey: "AIzaSyCmLD1bR7gJx2hnds5ejpDwApypazuQYd0",
    authDomain: "exam-retake-3bca8.firebaseapp.com",
    projectId: "exam-retake-3bca8",
    storageBucket: "exam-retake-3bca8.appspot.com",
    messagingSenderId: "220647874527",
    appId: "1:220647874527:web:2e907835e90bb8240cee6a"
};

export const notificationTypes = {
  SUCCESS: 1,
  ERROR: 2,
};
