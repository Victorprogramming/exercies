import api from '../utils/api.js';
import events from '../utils/events.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  let wrapper, id, ofedit;

  const render = ({ user, route }) => {
    if (ofedit && api.offer.find((ofedit) => ofedit.id === id)) {
      return;
    }

    if (wrapper) {
      parent.removeChild(wrapper);
    }

    if (!(id = route[1]) || !(ofedit = api.offer.find((ofedit) => ofedit.id === id))) {
      wrapper = htmlToParent(
        `<div class="container" style="margin-top:2%; margin-bottom:2%">
          <div class="d-flex justify-content-center h-100">
            <div class="card" style="height: auto">
            ${
              api.isLoading
                ? '<h4>Loading...<h4>'
                : `<h4>Offer with id ${id} not found.<br/><br/>Migh have been deleted or might be in create operation.</h4>`
            }
            </div>
          </div>
        </div>`
      );
    } else {
      wrapper = htmlToParent(
        `<div class="container" style="margin-top:2%; margin-bottom:2%">
            <div class="d-flex justify-content-center h-100">
                <div class="card" style="height: auto">
                    <div class="card-header">
                        <h3>Edit offer</h3>
                        <div class="d-flex justify-content-end social_icon">
                            <span><i class="fab fa-facebook-square"></i></span>
                            <span><i class="fab fa-google-plus-square"></i></span>
                            <span><i class="fab fa-twitter-square"></i></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <form style="width: 100%;" action="" method="">
                            <div class="input-group form-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="product" value="${offer.name}" name="product">

                            </div>
                            <div class="input-group form-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                                </div>
                                <textarea style="height: auto; width: 85%; resize: none;" placeholder="description"
                                    name="description">${offer.description}</textarea>
                            </div>
                            <div class="input-group form-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="price" value="${offer.price}" name="price">
                            </div>
                            <div class="input-group form-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="picture url" value="${offer.imageUrl}"
                                    name="pictureUrl">
                            </div>

                            <input type="submit" value="Edit" class="btn float-right login_btn">
                        </form>
                    </div>
                </div>
            </div>
        </div>`
      );

      wrapper.querySelector('form').addEventListener('submit', (event) => {
        event.preventDefault();
        api.edit(
          ...Array.from(event.target)
            .slice(0, 4)
            .map((el) => el.value.trim()),
          offer
        );
      });
    }
  };


  render({ user: api.user, route });
  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    cleanUp: () => {
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
      parent.removeChild(wrapper);
    },
  };
};
