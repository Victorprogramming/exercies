import { routes } from '../utils/constants.js';
import api from '../utils/api.js';
import events from '../utils/events.js';
import { parseHTMLElement, parseHTMLElements } from '../utils/utils.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(`<div style="margin-top:5%; margin-bottom: 5%;" class="page-header">
  <div class="container">
      <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="page-caption">
                  <h1 style="padding: 9rem" class="page-title">Your Online Shop Center</h1>
              </div>
          </div>
      </div>
  </div>
</div>`);

  render({ user: api.user, route });

  events.listen('authChange', `${route[0]}-${routerID}`, render);
  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    wrapper,
    cleanUp: () => {
      events.unlisten('authChange', `${route[0]}-${routerID}`);
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
    },
  };
};
