export default () => {
  document.querySelector('footer').innerHTML =
    '<p><a href="https://softuni.bg">Software University</a> - JS Applications @ 2020</p>';
};
