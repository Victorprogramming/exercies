import { database, edit } from '../utils/api.js';

export default ({ main, route }) => {
  let isMounted = true;
  main.innerHTML = `<h1>Loading...</h1>`;

  database.child(route[1]).once('value', (snapshot) => {
    if (!isMounted) {
      return;
    }

    if (snapshot.exists()) {
      const shoe = snapshot.val();
      main.innerHTML = `<h1>Edit Offer</h1>
        <form>
            <div><input type="text" placeholder="Name..." value="${shoe.name}"></div>
            <div><input type="text" placeholder="Price..." value="${shoe.price}"></div>
            <div><input type="text" placeholder="Image url..." value="${shoe.imageUrl}"></div>
            <div><textarea placeholder="Give us some description about this offer...">${shoe.description}</textarea></div>
            <div><input type="text" placeholder="Brand..." value="${shoe.brand}"></div>
            <div><button>Edit</button></div>
        </form>`;

      main.lastChild.addEventListener('submit', (event) => {
        event.preventDefault();
        const [name, price, imageUrl, description, brand] = Array.from(main.lastChild)
          .slice(0, 5)
          .map((el) => el.value.trim());

        const updateObj = Object.fromEntries(
          Object.entries({ name, price, imageUrl, description, brand }).filter(([key, value]) => value !== shoe[key])
        );

        edit(route[1], updateObj);
      });
    } else {
      main.innerHTML = `<a href="#/${routes.home}">This offer does not exist! Click here to check the collection.</a>`;
    }
  });

  return () => {
    isMounted = false;
  };
};
