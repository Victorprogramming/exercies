import { routes } from '../utils/constants.js';
import { signIn } from '../utils/api.js';

export default ({ main }) => {
  main.innerHTML = `<h1>Login</h1>
    <p class="form-info">Don't have account? <a href="#/${routes.register}">Register now</a> and fix that!</p>
    <form action="">
        <div><input type="email" placeholder="Email..."></div>
        <div><input type="password" placeholder="Password..."></div>
        <div><button>Login</button></div>
    </form>`;

  main.lastChild.addEventListener('submit', (event) => {
    event.preventDefault();
    const [email, password] = Array.from(event.target)
      .slice(0, 2)
      .map((el) => el.value.trim());

    signIn(email, password);
  });
};
