import { routes } from '../utils/constants.js';
import { signUp } from '../utils/api.js';

export default ({ main }) => {
  main.innerHTML = `<h1>Register</h1>
    <p class="form-info">Already registered? <a href="#/${routes.login}">Login now</a> and have some fun!</p>
    <form action="">
        <div><input type="email" placeholder="Email..."></div>
        <div><input type="password" placeholder="Password"></div>
        <div><input type="password" placeholder="Re-password"></div>
        <div><p class="message"></p><button>Register</button></div>
    </form>`;

  main.lastChild.addEventListener('submit', (event) => {
    event.preventDefault();
    const [email, password] = Array.from(event.target)
      .slice(0, 3)
      .map((el) => el.value.trim());

    // TO DO Validation

    signUp(email, password);
  });
};
