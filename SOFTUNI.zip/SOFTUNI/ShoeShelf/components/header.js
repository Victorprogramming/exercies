import { auth, signOut } from '../utils/api.js';
import { routes } from '../utils/constants.js';

export default () => {
  const header = document.querySelector('header');
  header.innerHTML = `<nav><ul></ul></nav>`;

  const ul = header.firstChild.firstChild;

  auth.onAuthStateChanged((user) => {
    if (user) {
      ul.innerHTML = `<li><a href="#/${routes.create}">Create new offer</a></li> 
        <li><a href="#/${routes.home}"><img src="./static/sneakers.png" alt=""></a></li> 
        <li>Welcome, ${user.email} | <a href="">Logout</a></li>`;

      ul.lastChild.lastChild.addEventListener('click', (event) => {
        event.preventDefault();
        signOut();
      });
    } else {
      ul.innerHTML = `<li class="site-logo">Shoe</li>
      <li><a href="#/${routes.home}"><img src="./static/sneakers.png" alt=""></a></li> 
      <li class="site-logo">Shelf</li>`;
    }
  });
};
