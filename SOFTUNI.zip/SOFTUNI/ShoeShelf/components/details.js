import { database, remove } from '../utils/api.js';
import { routes } from '../utils/constants.js';

export default ({ main, user, route }) => {
  let isMounted = true;
  main.innerHTML = `<div class="offer-details">Loading...</div>`;

  database.child(route[1]).once('value', (snapshot) => {
    if (!isMounted) {
      return;
    }

    if (snapshot.exists()) {
      const shoe = snapshot.val();

      const isCreator = shoe.creator === user.uid,
        isBought = !!shoe.users && !!shoe.users[user.uid];

      main.firstChild.innerHTML = `<h1>${shoe.name}</h1>
        <div class="info">
            <img src="${shoe.imageUrl}" alt="">
            <div class="description">
                ${shoe.description}<br><br>
                <p class="price">$${shoe.price}</p>
            </div>
        </div>
        <div class="actions">
            ${
              isCreator
                ? `<a href="#/${routes.edit}/${route[1]}">Edit</a> <a href="#/">Delete</a>`
                : isBought
                ? '<span>You bought it</span>'
                : '<a href="#/">Buy</a>'
            }
        </div>`;

      if (isCreator) {
        main.firstChild.lastChild.children[1].addEventListener('click', (event) => {
          event.preventDefault();
          remove(route[1]);
        });
      } else {
        if (!isBought) {
          main.firstChild.lastChild.children[0].addEventListener('click', (event) => {
            event.preventDefault();
            database.child(`${route[1]}/users/${user.uid}`).set(user.email, (error) => {
              if (error) {
                console.error(error.message);
              } else {
                if (isMounted) {
                  main.firstChild.lastChild.innerHTML = '<span>You bought it</span>';
                }
              }
            });
          });
        }
      }
    } else {
      main.firstChild.innerHTML = `<a href="#/${routes.home}">This offer does not exist! Click here to check the collection.</a>`;
    }
  });

  return () => {
    isMounted = false;
  };
};
