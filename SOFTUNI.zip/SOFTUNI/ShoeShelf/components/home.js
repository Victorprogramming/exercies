import { database } from '../utils/api.js';
import { routes } from '../utils/constants.js';

export default ({ main, user, route }) => {
  let isMounted = true;
  if (user) {
    main.innerHTML = `<div class="shoes">Loading...</div>`;

    database.once('value', (snapshot) => {
      if (!isMounted) {
        return;
      }

      if (snapshot.exists()) {
        const shoes = Object.entries(snapshot.val())
          .map(([uuid, data]) => ({ uuid, ...data }))
          .sort((a, b) => Object.keys(b).length - Object.keys(a).length);
        main.firstChild.innerHTML = shoes
          .map(
            (shoe) =>
              `<div class="shoe">
                    <img src="${shoe.imageUrl}">
                    <h3>${shoe.name}</h3>
                    <a href="#/${routes.details}/${shoe.uuid}">Buy it for $${shoe.price}</a>
                </div>`
          )
          .join('');
      } else {
        main.firstChild.innerHTML = `<a style="width: 100%;" href="#/${routes.create}"><h1>No shoes to display. Be the first to create a new offer...</h1></a>`;
      }
    });
  } else {
    main.innerHTML = `<div class="container">
        <div class="about-us">
            <div>
                <img src="../static/shoes.jpg" alt="">
                <img src="../static/shoes2.jpg" alt="">
            </div>
            <p><a href="#/${routes.register}">Register Now</a> and Try it!</p>
        </div>
    </div>`;
  }

  return () => {
    isMounted = false;
  };
};
