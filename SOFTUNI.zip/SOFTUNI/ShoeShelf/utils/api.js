import { goToRoute, routes } from './constants.js';

firebase.initializeApp({
  apiKey: 'AIzaSyDZ3-Whf71Hrew__ytI5asf1kiNg8IZKCM',
  authDomain: 'shoeshelf-4adf9.firebaseapp.com',
  databaseURL: 'https://shoeshelf-4adf9.firebaseio.com',
  projectId: 'shoeshelf-4adf9',
  storageBucket: 'shoeshelf-4adf9.appspot.com',
  messagingSenderId: '731602598527',
  appId: '1:731602598527:web:607f746f4f321e4216dd4a',
});

const auth = firebase.auth();
const database = firebase.database().ref('shoes');

const signUp = (email, password) => {
  auth
    .createUserWithEmailAndPassword(email, password)
    .then((user) => {
      console.log('Successful registration!');
    })
    .catch((error) => {
      console.error(error.message);
    });
};

const signIn = (email, password) => {
  auth
    .signInWithEmailAndPassword(email, password)
    .then((user) => {
      console.log('Successful login!');
    })
    .catch((error) => {
      console.error(error);
    });
};

const signOut = () => {
  auth
    .signOut()
    .then(() => {
      console.log('Sign-out successful.');
    })
    .catch((error) => {
      console.error(error.message);
    });
};

const create = (data) => {
  database.push().set(data, (error) => {
    if (error) {
      console.error(error.message);
    } else {
      goToRoute([routes.home]);
      console.log('Successfuly created offer.');
    }
  });
};

const edit = (uuid, data) => {
  database.child(uuid).update(data, (error) => {
    if (error) {
      console.error(message.error);
    } else {
      goToRoute([routes.details, uuid]);
    }
  });
};

const remove = (uid) => {
  database
    .child(uid)
    .remove()
    .then(() => goToRoute([routes.home]))
    .catch((error) => console.error(error.message));
};

export { auth, database, signUp, signIn, signOut, create, edit, remove };
