export const routes = {
  home: '',
  login: 'login',
  register: 'register',
  create: 'create',
  edit: 'edit',
  details: 'details',
};

const authResRoutes = [routes.login, routes.register];
const nonAuthResRoutes = [routes.create, routes.edit, routes.details];

export const isValidRoute = (route, user) => {
  if (
    !Object.values(routes).includes(route) ||
    (!!user && authResRoutes.includes(route)) ||
    (!user && nonAuthResRoutes.includes(route))
  ) {
    return false;
  }

  return true;
};

export const getRoute = () => window.location.hash.split(/[#\/]/g).filter((s) => !!s);
export const goToRoute = (params = []) => (window.location.hash = `#/${params.join('/')}`);
