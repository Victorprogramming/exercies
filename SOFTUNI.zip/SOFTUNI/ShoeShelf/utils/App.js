import { routes, getRoute, goToRoute, isValidRoute } from './constants.js';
import { auth } from './api.js';
import header from '../components/header.js';
import footer from '../components/footer.js';
import home from '../components/home.js';
import login from '../components/login.js';
import register from '../components/register.js';
import create from '../components/create.js';
import edit from '../components/edit.js';
import details from '../components/details.js';

export default (() => {
  if (window.location.pathname !== '/') {
    [window.location.hash, window.location.pathname] = [`#${window.location.pathname}`, ''];
    return;
  }

  header();
  footer();

  let user;
  let route;

  let component = {
    [routes.home]: home,
    [routes.login]: login,
    [routes.register]: register,
    [routes.create]: create,
    [routes.edit]: edit,
    [routes.details]: details,
  };

  const main = document.querySelector('main');

  let willUnmount;
  const mountComponent = () => {
    if (willUnmount) {
      willUnmount();
    }

    willUnmount = component[route[0]]({ main, user, route });
  };

  const checkRoutes = () => {
    route = getRoute();
    if (!isValidRoute(route[0], user)) {
      goToRoute([routes.home]);
      route = [routes.home];
    }

    mountComponent();
  };

  window.addEventListener('hashchange', checkRoutes);

  auth.onAuthStateChanged((currentUser) => {
    user = currentUser;
    checkRoutes();
  });
})();
