import { isValidEmail } from './utils.js';
import { routes, notificationTypes, firebaseConfig } from './constants.js';
import { goToRoute } from './router.js';
import events from '../utils/events.js';

class API {
  constructor() {
    if (!!API.instance) {
      return API.instance;
    }

    API.instance = this;

    firebase.initializeApp(firebaseConfig);
    this.auth = firebase.auth();
    this.firestore = firebase.firestore().collection('offers');

    this.isLoading = true;
    this.offers = [];

    return this;
  }

  _onSnapshot;
  dataListener = (user) => {
    if (user) {
      this._onSnapshot = this.firestore.onSnapshot(({ docs }) => {
        this.isLoading = false;
        this.offers = docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        events.trigger('dataChange', true);
      });
    } else {
      if (this._onSnapshot) {
        this._onSnapshot();
      }
      this.isLoading = true;
      this.offers = [];
    }
  };

  get user() {
    return this.auth.currentUser;
  }

  notify = (message, type, timeout) => events.trigger('notification', { message, type, timeout });

  createUserWithEmailAndPassword = (email, password, confirmPassword) => {
    if (!isValidEmail(email)) {
      return this.notify('Email address is not in a valid format!');
    }

    if (password.length < 6) {
      return this.notify('Password must be at least 6 characters long!');
    }

    if (confirmPassword !== password) {
      return this.notify("Passwords don't match!");
    }

    this.auth
      .createUserWithEmailAndPassword(email, password)
      .then(() => {
        this.notify('Successful registration!', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };

  signInWithEmailAndPassword = (email, password) => {
    if (!isValidEmail(email)) {
      return this.notify('Email address is not in a valid format!');
    }

    if (!password.length) {
      return this.notify('Please enter a password!');
    }

    this.auth
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        this.notify('Logged in successfully', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };

  signOut = () => {
    this.auth
      .signOut()
      .then(() => {
        this.notify('Successful logout', notificationTypes.SUCCESS);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };

  create = (name, description, price, imageUrl) => {
    if ([name, description, price].filter((value) => !value).length) {
      return this.notify("Product name, description and price can't be empty!");
    }

    if (!imageUrl.startsWith('https://')) {
      return this.notify('The input field for imageUrl, must be valid url (starts with "https://")');
    }

    this.firestore
      .add({
        name,
        description,
        price,
        imageUrl,
        creator: this.user.uid,
      })
      .then(() => {
        this.notify('Created successfully', notificationTypes.SUCCESS);
        goToRoute([routes.DASHBOARD]);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };

  edit = (name, description, price, imageUrl, offer) => {
    if ([name, description, price].filter((value) => !value).length) {
      return this.notify("Product name, description and price can't be empty!");
    }

    if (!imageUrl.startsWith('https://')) {
      return this.notify('The input field for imageUrl, must be valid url (starts with "https://")');
    }

    const entries = Object.entries({ name, description, price, imageUrl }).filter(
      ([field, value]) => value !== offer[field]
    );

    if (!entries.length) {
      this.notify('Eddited successfully', notificationTypes.SUCCESS);
      return goToRoute([routes.DETAILS, offer.id]);
    }

    this.firestore
      .doc(offer.id)
      .update(Object.fromEntries(entries))
      .then(() => {
        this.notify('Eddited successfully', notificationTypes.SUCCESS);
        goToRoute([routes.DETAILS, offer.id]);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };

  delete = (id) => {
    this.firestore
      .doc(id)
      .delete()
      .then(() => {
        this.notify('Deleted successfully', notificationTypes.SUCCESS);
        goToRoute([routes.DASHBOARD]);
      })
      .catch((error) => {
        this.notify(error.message);
      });
  };
}

const api = new API();
export default api;
