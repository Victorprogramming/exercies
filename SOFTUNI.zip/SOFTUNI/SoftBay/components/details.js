import api from '../utils/api.js';
import { routes } from '../utils/constants.js';
import events from '../utils/events.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  let wrapper;
  const render = ({ user, route }) => {
    if (wrapper) {
      parent.removeChild(wrapper);
    }

    let id, offer;

    if (!(id = route[1]) || !(offer = api.offers.find((offer) => offer.id === id))) {
      wrapper = htmlToParent(
        `<div style="margin-top:3%; margin-bottom: 5%;" class="mr-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
            ${
              api.isLoading
                ? '<h4>Loading...</h4>'
                : `<h4>Offer with id ${id} was not found.<br/><br/>Migh have been deleted or might be in create operation.</h4>`
            }
        </div>`
      );
    } else {
      wrapper = htmlToParent(
        `<div style="margin-top:3%; margin-bottom: 5%;" class="mr-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
            <h2 class="display-5">${offer.name}</h2>
            <div class="shadow-sm mx-auto"
                style="border: 1px solid gray; width: 50%; height: auto; border-radius: 21px 21px 0 0;">
                <img src="${offer.imageUrl}" style="display: block; margin: 0 auto" />
            </div>
            <div class="container">
                <label for=""></label>
                <p class="text-dark">${offer.description}</p>
                <p class="text-dark font-weight-bold">Price: ${offer.price} BGN</p>
            </div>
        </div>`
      );
    }
  };

  render({ user: api.user, route });

  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    cleanUp: () => {
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
      parent.removeChild(wrapper);
    },
  };
};
