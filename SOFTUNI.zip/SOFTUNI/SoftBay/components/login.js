import api from '../utils/api.js';
import { routes } from '../utils/constants.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(
    `<div class="container" style="margin-top: 5%; margin-bottom: 5%;">
        <div class="d-flex justify-content-center h-100">
            <div class="card">
                <div class="card-header">
                    <h3>Login</h3>
                    <div class="d-flex justify-content-end social_icon">
                        <span><i class="fab fa-facebook-square"></i></span>
                        <span><i class="fab fa-google-plus-square"></i></span>
                        <span><i class="fab fa-twitter-square"></i></span>
                    </div>
                </div>
                <div class="card-body">
                    <form method="" action="">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="email" name="email" class="form-control" placeholder="Email">

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" name="password" class="form-control" placeholder="password">
                        </div>

                        <input type="submit" value="Login" class="btn float-right login_btn">
                    </form>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-center links">
                        Don't have an account?<a class="text-warning" href="#/${routes.REGISTER}">Register</a>
                    </div>
                </div>
            </div>
        </div>
    </div>`
  );

  wrapper.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    api.signInWithEmailAndPassword(
      ...Array.from(event.target)
        .slice(0, 2)
        .map((input) => input.value.trim())
    );
  });

  return {
    wrapper,
    cleanUp: () => {},
  };
};
