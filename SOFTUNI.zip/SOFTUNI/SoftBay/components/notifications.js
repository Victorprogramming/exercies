import { parseHTMLElement } from '../utils/utils.js';
import events from '../utils/events.js';
import { notificationTypes } from '../utils/constants.js';

export default ({ parent }) => {
  const wrapper = parent.appendChild(parseHTMLElement(`<section id="notifications"></section>`));
  const successBox = wrapper.appendChild(
    parseHTMLElement(`<div class="p-3 mb-2 bg-success w-50 text-white text-center" id="successNotification"></div>`)
  );
  const errorBox = wrapper.appendChild(
    parseHTMLElement(`<div class="p-3 mb-2 bg-danger w-50 text-white text-center" id="errorNotification"></div>`)
  );

  let [errorHide, successHide, errorHideTimeout, successHideTimeout] = [false, false];

  events.listen('notification', 'notifications', ({ message = '', type = notificationTypes.ERROR, timeout = 3 }) => {
    if (type === notificationTypes.ERROR) {
      errorBox.textContent = message;
      errorBox.style.display = 'block';
      if (errorHide === true) {
        clearTimeout(errorHideTimeout);
      }

      errorHide = true;
      errorHideTimeout = setTimeout(() => {
        errorHide = false;
        errorBox.style.display = 'none';
      }, timeout * 1000);
    } else {
      successBox.textContent = message;
      successBox.style.display = 'block';
      if (successHide === true) {
        clearTimeout(successHideTimeout);
      }

      successHide = true;
      successHideTimeout = setTimeout(() => {
        successHide = false;
        successBox.style.display = 'none';
      }, timeout * 1000);
    }
  });

  return {
    wrapper,
    cleanUp: () => {
      events.unlisten('notification', 'notifications');
    },
  };
};
