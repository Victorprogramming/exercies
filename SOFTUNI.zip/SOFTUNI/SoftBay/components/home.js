export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(
    `<div style="margin-top:5%; margin-bottom: 5%;" class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-caption">
                        <h1 style="padding: 9rem" class="page-title">Your Online Shop Center</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>`
  );

  return {
    wrapper,
    cleanUp: () => {},
  };
};
