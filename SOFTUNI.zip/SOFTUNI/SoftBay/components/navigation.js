import { routes } from '../utils/constants.js';
import { parseHTMLElement, parseHTMLElements } from '../utils/utils.js';
import api from '../utils/api.js';
import events from '../utils/events.js';

export default ({ parent }) => {
  const wrapper = parent.appendChild(
    parseHTMLElement(
      `<nav class="navbar navbar-light bg-light static-top">
          <div class="container">
          </div>
      </nav>`
    )
  );

  const container = wrapper.querySelector('.container');
  let partials = [];

  const render = ({ user, route }) => {
    partials.forEach((el) => container.removeChild(el));
    partials.length = 0;

    if (user) {
      partials = parseHTMLElements(
        `<a class="navbar-brand" href="#/${routes.HOME}">SoftBay</a>`,
        `<a class="navbar-item" href="#/${routes.DASHBOARD}">Dashboard</a>`,
        `<a class="navbar-item" href="#/${routes.ADD}">Create Offer</a>`,
        `<a class="navbar-item" href="#/">Logout</a>`
      );

      partials[3].addEventListener('click', (event) => {
        event.preventDefault();
        api.signOut();
      });
    } else {
      partials = parseHTMLElements(
        `<a class="navbar-brand" href="#/${routes.HOME}">SoftBay</a>`,
        `<a class="btn btn-warning" href="#/${routes.LOGIN}">Login</a>`
      );
    }

    container.append(...partials);
  };

  render({ user: api.user });
  events.listen('authChange', 'navigation', render);

  return {
    wrapper,
    cleanUp: () => events.unlisten('authChange', 'navigation'),
  };
};
