import api from '../utils/api.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(
    `<div class="container" style="margin-top:5%; margin-bottom:5%">
        <div class="d-flex justify-content-center h-100">
            <div class="card" style="height: auto">
                <div class="card-header">
                    <h3>Create offer</h3>
                    <div class="d-flex justify-content-end social_icon">
                        <span><i class="fab fa-facebook-square"></i></span>
                        <span><i class="fab fa-google-plus-square"></i></span>
                        <span><i class="fab fa-twitter-square"></i></span>
                    </div>
                </div>
                <div class="card-body">
                    <form action="#" method="">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="product" name="product">

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <textarea style="height: auto; width: 85%; resize: none;" placeholder="description"
                                name="description"></textarea>
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="price" name="price">
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="picture url" name="pictureUrl">
                        </div>

                        <input type="submit" value="Create" class="btn float-right login_btn">
                    </form>
                </div>
            </div>
        </div>
    </div>`
  );

  wrapper.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    api.create(
      ...Array.from(event.target)
        .slice(0, 4)
        .map((input) => input.value.trim())
    );
  });

  return {
    wrapper,
    cleanUp: () => {},
  };
};
