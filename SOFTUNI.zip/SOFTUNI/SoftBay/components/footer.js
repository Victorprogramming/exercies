import { parseHTMLElement } from '../utils/utils.js';

export default ({ parent }) => {
  const wrapper = parent.appendChild(
    parseHTMLElement(
      `<footer class="page-footer font-small blue">
          <div class="footer-copyright text-center py-3">© 2019 Copyright:
              <a href="#/"> SoftBay.com</a>
          </div>
      </footer>`
    )
  );

  return {
    wrapper,
    cleanUp: () => {},
  };
};
