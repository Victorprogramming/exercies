import api from '../utils/api.js';
import { routes } from '../utils/constants.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  const wrapper = htmlToParent(
    `<div class="container" style="margin-top:5%; margin-bottom:5%">
        <div class="d-flex justify-content-center h-100">
            <div class="card">
                <div class="card-header">
                    <h3>Registration</h3>
                    <div class="d-flex justify-content-end social_icon">
                        <span><i class="fab fa-facebook-square"></i></span>
                        <span><i class="fab fa-google-plus-square"></i></span>
                        <span><i class="fab fa-twitter-square"></i></span>
                    </div>
                </div>
                <div class="card-body">
                    <form method="" action="">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" name="email" class="form-control" placeholder="Email">

                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" name="password" class="form-control" placeholder="password">
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                            </div>
                            <input type="password" name="repeatPassword" class="form-control" placeholder="repeat password">
                        </div>

                        <input type="submit" value="Register" class="btn float-right login_btn">
                    </form>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-center links">
                        Already have an account?<a class="text-warning" href="#/${routes.LOGIN}">Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>`
  );

  wrapper.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault();
    api.createUserWithEmailAndPassword(
      ...Array.from(event.target)
        .slice(0, 3)
        .map((input) => input.value.trim())
    );
  });

  return {
    wrapper,
    cleanUp: () => {},
  };
};
