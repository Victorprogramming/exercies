import api from '../utils/api.js';
import { routes } from '../utils/constants.js';
import events from '../utils/events.js';

export default ({ parent, htmlToParent, route, routerID }) => {
  let wrapper;
  const render = ({ user, route }) => {
    if (wrapper) {
      parent.removeChild(wrapper);
    }

    if (!api.offers.length) {
      wrapper = htmlToParent(
        `<table style="margin: 0 auto; margin-top:5%; margin-bottom: 5%; width: 95%;" class="table table-hover">
            <thead>
                <tr class="bg-warning"><th>#</th><th>Name</th><th>Description</th><th>Price</th><th>Details</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;" colspan="6">
                        <h2 style="font-style: italic;">${
                          api.isLoading ? 'Loading...' : 'There are no offers, we are very sorry...'
                        }</h2>
                    </td>
                </tr>
            </tbody>
        </table>`
      );
    } else {
      wrapper = htmlToParent(
        `<table style="margin: 0 auto; margin-top:5%; margin-bottom: 5%; width: 95%;" class="table table-hover">
            <thead>
                <tr class="bg-warning"><th>#</th><th>Name</th><th>Description</th><th>Price</th><th>Details</th><th>Actions</th></tr>
            </thead>
            <tbody>
                ${api.offers
                  .map(
                    ({ id, name, description, price, imageUrl, creator }, i) =>
                      `<tr>
                            <td class="">${i}</td>
                            <td class="">${name}</td>
                            <td class="description">${description}</td>
                            <td class="">${price}</td>
                            <td>
                                <a href='#/${routes.DETAILS}/${id}' class="btn-primary btn">Order details</a>
                            </td>
                            <td>
                                ${
                                  creator === user.uid
                                    ? `<a href='#/${routes.DELETE}/${id}' class="btn-danger btn">Delete</a>
                                        <a href='#/${routes.EDIT}/${id}' class="btn-info btn">Edit</a>`
                                    : ''
                                }
                            </td>
                        </tr>`
                  )
                  .join('')}
            </tbody>
        </table>`
      );
    }
  };

  render({ user: api.user, route });

  events.listen('dataChange', `${route[0]}-${routerID}`, () => render({ user: api.user, route }));

  return {
    cleanUp: () => {
      events.unlisten('dataChange', `${route[0]}-${routerID}`);
      parent.removeChild(wrapper);
    },
  };
};
